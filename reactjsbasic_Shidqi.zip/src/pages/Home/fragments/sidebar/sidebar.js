import './style.css';
function Sidebar () {
    return(
       
<div className='sidebar-wrapper'>
    <h1>Menu</h1>
</div>
        
    );
}
export default Sidebar